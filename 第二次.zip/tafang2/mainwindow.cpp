#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPoint>
#include<QImage>
#include <QTimer>
#include"play.h"
#include"tower.h"
#include<QList>
#include<QDebug>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(1024,512);
    setWindowTitle("塔防");

    QImage title;

   setWindowIcon(QIcon(":/pic2/biene_laufen_r1_b0.png"));
   QTimer *timer=new QTimer(this);
    QTimer *timer2=new QTimer(this);
    QTimer *timer3=new QTimer(this);
    timer->start(100);
    timer2->start(300);
    timer3->start(500);
    //connect(ui->rembtn1,&QPushButton::clicked,this,[=](){
   //     towerlist.removeAt(0);
    //});
   connect(ui->b1,&QPushButton::clicked,this,[=](){
       settower1();
       connect(timer2,&QTimer::timeout,this,[=](){
           MyObj *obj1=new MyObj(QPoint(ui->b1->x(),ui->b1->y()-40),QPoint(1024,240),":/pic2/flash_r0_b0.png",1);
           obj_list.push_back(obj1);
           obj1->move();
           update();
       });
   });
   connect(ui->b2,&QPushButton::clicked,this,[=](){
       settower2();
               connect(timer3,&QTimer::timeout,this,[=](){
                   MyObj *obj2=new MyObj(QPoint(ui->b2->x(),ui->b2->y()-40),QPoint(1024,240),":/pic2/fire_r0_b0.png",2);
                   obj_list.push_back(obj2);
                   obj2->move();
                   update();
   });});
   connect(ui->startbtn,&QPushButton::clicked,[=](){
       Enemy *ene1=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/biene_laufen_r0_b0.png",1);
   ene_list.push_back(ene1);
   connect(timer,&QTimer::timeout,this,[=](){ene1->move();});
   update();
   });

}
void MainWindow::settower1()
{
    Tower * newtower=new Tower(QPoint(64,224),":/pic2/flash_tower_r0_b1.png");
    towerlist.push_back(newtower);

    update();
}
void MainWindow::settower2()
{
    Tower * newtower=new Tower(QPoint(96,200),":/pic2/fire_tower_r0_b0.png");
    towerlist.push_back(newtower);
    update();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QImage pix;
    pix.load(":/TileB.png");

    QImage road;
    road=pix.copy(96,64,96,32);
    QImage tree;
    tree=pix.copy(192,128,64,64);
    QImage home;
    home=pix.copy(352,352,64,64);
    painter.drawImage(0,224,home);

for(int i=0;i<=20;i++)
{
    painter.drawImage(96*i+64,224,road);
    painter.drawImage(96*i+64,256,road);
    painter.drawImage(64*i,160,tree);
    painter.drawImage(64*i,288,tree);
}
foreach(Tower *tower,towerlist)
    tower->draw(&painter);
foreach (MyObj *obj,obj_list)
{
    if(obj->curtpos.x()<ene_list[0]->curtpos.x())
    obj->draw(&painter);
    else
    {obj_list.removeOne(obj);
        if(obj->damage==1)
        ene_list[0]->life=ene_list[0]->life-1;
        if(obj->damage==2)
            ene_list[0]->life=ene_list[0]->life-2;
    qDebug("%d",ene_list[0]->life);}}
foreach(Enemy *ene,ene_list)
 { if(ene->life<0)
   ene_list.removeOne(ene);
}
foreach(Enemy *ene,ene_list)
    ene->draw(&painter);
}
MainWindow::~MainWindow()
{
    delete ui;
}

