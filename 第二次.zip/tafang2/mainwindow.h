#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "tower.h"
#include"myobj.h"
#include"enemy.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
    int posx=992;
    QList<Tower*>towerlist;
    void settower1();
    void settower2();
    QList <MyObj*> obj_list;
    QList<Enemy*>ene_list;
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
