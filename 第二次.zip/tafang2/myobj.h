#ifndef MYOBJ_H
#define MYOBJ_H

#include <QObject>
#include<QPropertyAnimation>
#include<QPoint>
#include<QPainter>
#include<QPixmap>
class MyObj : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint curtpos READ getcurtpos WRITE setcurtpos)
public:
    MyObj(QPoint sttpos,QPoint tarpos,QString filename,int kind);
    void draw(QPainter *painter);
    void move();
    QPoint getcurtpos();
    void setcurtpos(QPoint pos);
    int damage;
    QPoint sttpos;
    QPoint tarpos;
    QPoint curtpos;
    QPixmap pix;

signals:

};

#endif // MYOBJ_H
