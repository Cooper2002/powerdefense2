#include "myobj.h"
#include<QPropertyAnimation>
#include<QPoint>
#include<QPainter>
#include<QPixmap>
MyObj::MyObj( QPoint sttpos,QPoint tarpos,QString filename,int kind) : QObject(0),pix(filename)
{
    this->curtpos=sttpos;
    this->sttpos=sttpos;
    this->tarpos=tarpos;
    if(kind==1)damage=1;
    if(kind==2)damage=2;
}
void MyObj::draw(QPainter *painter)
{
    painter->drawPixmap(curtpos,pix);
}
void MyObj::move()
{
    QPropertyAnimation *animaton =new QPropertyAnimation(this,"curtpos");
    animaton->setDuration(2000);
    animaton->setStartValue(sttpos);
    animaton->setEndValue(tarpos);
    animaton->start();
}
QPoint MyObj::getcurtpos()
{
    return this->curtpos;
}
void MyObj:: setcurtpos(QPoint pos)
{
    this->curtpos=pos;
}
