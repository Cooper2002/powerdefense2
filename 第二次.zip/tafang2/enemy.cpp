#include "enemy.h"
#include<QPoint>
#include<QVector2D>
Enemy::Enemy(QPoint sttpos,QPoint tarpos,QString filename,int kind) : QObject(0),pix(filename)
{
    this->curtpos=sttpos;
    this->sttpos=sttpos;
    this->tarpos=tarpos;
    if (kind==1){speed=1;life=200;}
    if (kind==2){speed=4;life=20;}
}
void Enemy::move()
{
    QVector2D vector(tarpos-sttpos);
    vector.normalize();
    curtpos=curtpos+vector.toPoint()*speed;

}
void Enemy::draw(QPainter *painter)
{
    painter->drawPixmap(curtpos,pix);

}
