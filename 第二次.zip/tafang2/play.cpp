#include "play.h"
#include<QImage>
#include<QPainter>
